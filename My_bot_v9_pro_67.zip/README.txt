╔══════════════════════════════════════════════╗
║      KIBER STANSIYA OSINT PRO v3             ║
║      O'RNATISH VA ISHLATISH YO'RIQNOMASI     ║
╚══════════════════════════════════════════════╝

BIRINCHI MARTA O'RNATISH:
─────────────────────────
1. INSTALL.bat ni o'ng tugma → "Administrator sifatida ishga tushirish"
   (Python va kutubxonalar avtomatik o'rnatiladi)

2. .env faylini oching va ma'lumotlarni to'ldiring:
   API_ID=sizning_api_id
   API_HASH=sizning_api_hash
   BOT_TOKEN=sizning_bot_token
   SUPER_ADMIN_ID=sizning_telegram_id
   ADMIN_IDS=qo'shimcha_adminlar (ixtiyoriy)

3. START_BOT.bat ni o'ng tugma → "Administrator sifatida ishga tushirish"

KEYINGI SAFAR:
──────────────
Faqat START_BOT.bat ni ishga tushiring.

.ENV FAYLINI QAYERDAN OLISH:
─────────────────────────────
API_ID va API_HASH: https://my.telegram.org
BOT_TOKEN: @BotFather dan
SUPER_ADMIN_ID: @userinfobot ga /start yuboring

MUHIM:
──────
• Papkadan tashqariga ko'chirmang — barcha fayllar bir joyda bo'lishi kerak
• Birinchi ishga tushirishda userbot uchun telefon raqam so'raladi
• Internet va VPN kerak bo'lishi mumkin
