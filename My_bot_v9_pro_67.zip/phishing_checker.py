# phishing_checker.py — Fishing/Scam havola tekshiruv moduli
import os
import ssl
import socket
import sqlite3
import base64
import unicodedata
import urllib.parse
import datetime
import asyncio
from concurrent.futures import ThreadPoolExecutor

import requests

executor = ThreadPoolExecutor(max_workers=10)

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "phishing_stats.db")

SUSPICIOUS_TLDS = {
    ".xyz", ".top", ".click", ".tk", ".ml", ".ga", ".cf", ".gq",
    ".pw", ".cc", ".su", ".icu", ".live", ".online", ".site", ".fun", ".space"
}
SUSPICIOUS_COUNTRIES = {"Russia", "China", "North Korea", "Iran", "Belarus"}
SHORT_URL_DOMAINS = {
    "bit.ly", "t.co", "tinyurl.com", "goo.gl", "ow.ly", "short.link",
    "rebrand.ly", "cutt.ly", "clck.ru", "vk.cc"
}
SUSPICIOUS_KEYWORDS = {
    "login", "verify", "secure", "account", "update", "confirm", "bank",
    "payment", "signin", "password", "credential", "recover", "wallet",
    "billing", "kirish", "tasdiqlash", "xavfsiz", "hisob", "karta"
}
SCAM_BUTTON_WORDS = {
    "bonus", "sovg'a", "yutdi", "prize", "olish", "win", "gift",
    "бонус", "приз", "получить", "награда", "free", "tekin", "bepul",
    "yutuq", "lotereya", "lottery", "jackpot", "cash", "money"
}
TELEGRAM_DOMAINS = {"t.me", "telegram.me", "telegram.dog"}
UZBEK_BRANDS = {
    "payme": "payme.uz", "click": "click.uz", "uzcard": "uzcard.uz",
    "humo": "humo.uz", "kapitalbank": "kapitalbank.uz",
    "hamkorbank": "hamkorbank.uz", "myuzcard": "myuzcard.uz",
    "davrbank": "davrbank.uz", "aloqabank": "aloqabank.uz", "nbu": "nbu.uz",
}
GLOBAL_BRANDS = {
    "google": "google.com", "facebook": "facebook.com",
    "instagram": "instagram.com", "telegram": "telegram.org",
    "paypal": "paypal.com", "apple": "apple.com",
    "microsoft": "microsoft.com", "amazon": "amazon.com",
    "netflix": "netflix.com",
}
ALL_BRANDS = {**UZBEK_BRANDS, **GLOBAL_BRANDS}


# ── Ma'lumotlar bazasi ──────────────────────────────────────────────────────

def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS phishing_stats (
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            url     TEXT,
            risk    INTEGER,
            checked TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

def save_stat(url: str, risk: int):
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.execute("INSERT INTO phishing_stats (url, risk) VALUES (?, ?)", (url, risk))
        conn.commit()
        conn.close()
    except Exception:
        pass

def get_stats() -> tuple:
    try:
        conn = sqlite3.connect(DB_PATH)
        row = conn.execute(
            "SELECT COUNT(*), SUM(CASE WHEN risk >= 50 THEN 1 ELSE 0 END) FROM phishing_stats"
        ).fetchone()
        conn.close()
        return (row[0] or 0), (row[1] or 0)
    except Exception:
        return 0, 0


# ── Tarmoq tekshiruvlari ────────────────────────────────────────────────────

def get_redirect_chain(url: str) -> list:
    chain = []
    current = url
    try:
        for _ in range(10):
            resp = requests.get(current, allow_redirects=False, timeout=5, stream=True)
            chain.append(current)
            if resp.is_redirect and resp.headers.get("Location"):
                nxt = resp.headers["Location"]
                if not nxt.startswith("http"):
                    p = urllib.parse.urlparse(current)
                    nxt = f"{p.scheme}://{p.netloc}{nxt}"
                current = nxt
            else:
                break
    except Exception:
        pass
    return chain if chain else [url]

def check_ssl(domain: str) -> dict:
    try:
        ctx = ssl.create_default_context()
        with ctx.wrap_socket(socket.socket(), server_hostname=domain) as s:
            s.settimeout(5)
            s.connect((domain, 443))
            cert = s.getpeercert()
        expire = datetime.datetime.strptime(cert["notAfter"], "%b %d %H:%M:%S %Y %Z")
        days_left = (expire.replace(tzinfo=datetime.timezone.utc) - datetime.datetime.now(datetime.timezone.utc)).days
        issuer = dict(x[0] for x in cert.get("issuer", []))
        return {"valid": True, "days_left": days_left, "issuer": issuer.get("organizationName", "Noma'lum")}
    except Exception:
        return {"valid": False, "days_left": 0, "issuer": "Noma'lum"}

def check_whois(domain: str) -> dict:
    try:
        import whois
        w = whois.whois(domain)
        created = w.creation_date
        if isinstance(created, list):
            created = created[0]
        if created:
            if isinstance(created, str):
                created = datetime.datetime.fromisoformat(created)
            if created.tzinfo is None:
                created = created.replace(tzinfo=datetime.timezone.utc)
            age = (datetime.datetime.now(datetime.timezone.utc) - created).days
            return {"age_days": age, "registrar": w.registrar or "Noma'lum"}
    except Exception:
        pass
    return {"age_days": None, "registrar": "Noma'lum"}

def _get_geo(ip: str) -> dict:
    try:
        return requests.get(f"http://ip-api.com/json/{ip}", timeout=5).json()
    except Exception:
        return {}

def check_virustotal(url: str) -> dict:
    vt_key = os.getenv("VIRUSTOTAL_API_KEY", "").strip()
    if not vt_key:
        return {"available": False}
    try:
        url_id = base64.urlsafe_b64encode(url.encode()).decode().rstrip("=")
        headers = {"x-apikey": vt_key}
        resp = requests.get(f"https://www.virustotal.com/api/v3/urls/{url_id}", headers=headers, timeout=10)
        if resp.status_code == 200:
            stats = resp.json().get("data", {}).get("attributes", {}).get("last_analysis_stats", {})
            if stats:
                return {"available": True, "malicious": stats.get("malicious", 0),
                        "suspicious": stats.get("suspicious", 0), "total": sum(stats.values())}
        sub = requests.post("https://www.virustotal.com/api/v3/urls", headers=headers, data={"url": url}, timeout=10)
        if sub.status_code == 200:
            return {"available": True, "malicious": 0, "suspicious": 0, "total": 0, "pending": True}
    except Exception:
        pass
    return {"available": False}

def check_urlhaus(url: str) -> dict:
    try:
        resp = requests.post("https://urlhaus-api.abuse.ch/v1/url/", data={"url": url}, timeout=10).json()
        status = resp.get("query_status", "")
        if status == "is_available":
            return {"available": True, "found": True,
                    "threat": resp.get("threat", "malware"), "tags": resp.get("tags") or []}
        return {"available": True, "found": False, "threat": "", "tags": []}
    except Exception:
        return {"available": False}

def check_abuseipdb(ip: str) -> dict:
    abuse_key = os.getenv("ABUSEIPDB_API_KEY", "").strip()
    if not abuse_key or ip == "Noma'lum":
        return {"available": False}
    try:
        resp = requests.get(
            "https://api.abuseipdb.com/api/v2/check",
            params={"ipAddress": ip, "maxAgeInDays": 90},
            headers={"Key": abuse_key, "Accept": "application/json"}, timeout=8
        ).json()
        data = resp.get("data", {})
        return {"available": True, "abuse_score": data.get("abuseConfidenceScore", 0),
                "total_reports": data.get("totalReports", 0)}
    except Exception:
        return {"available": False}


# ── Telegram tekshiruvlari ─────────────────────────────────────────────────

async def probe_telegram_bot(userbot, username: str) -> dict:
    """Userbot orqali shubhali botga /start yuborib yashirin havolalarni topadi."""
    if not userbot:
        return {"available": False}
    try:
        entity = await userbot.get_entity(username)
        await userbot.send_message(entity, "/start")
        await asyncio.sleep(5)
        messages = await userbot.get_messages(entity, limit=8)

        urls = set()
        texts = []
        clicked_buttons = []
        last_msg_id = 0

        def _extract(msg):
            if msg.entities:
                for ent in msg.entities:
                    if hasattr(ent, "url") and ent.url:
                        urls.add(ent.url)
            if msg.reply_markup and hasattr(msg.reply_markup, 'rows'):
                for row in msg.reply_markup.rows:
                    for btn in row.buttons:
                        if hasattr(btn, "url") and btn.url:
                            urls.add(btn.url)

        for msg in messages:
            if msg.out:
                continue
            if msg.text:
                texts.append(msg.text[:300])
            _extract(msg)
            if msg.id > last_msg_id:
                last_msg_id = msg.id

        # Inline tugmalarni bosish (URL tugmalar emas)
        for msg in messages:
            if msg.out or not msg.reply_markup:
                continue
            if not hasattr(msg.reply_markup, 'rows'):
                continue
            for row in msg.reply_markup.rows:
                for btn in row.buttons:
                    if hasattr(btn, "url") and btn.url:
                        continue
                    btn_text = getattr(btn, "text", "") or ""
                    if len(clicked_buttons) >= 4:
                        break
                    try:
                        await btn.click()
                        clicked_buttons.append(btn_text)
                        await asyncio.sleep(3)
                        new_msgs = await userbot.get_messages(entity, limit=6)
                        for nm in new_msgs:
                            if nm.out or nm.id <= last_msg_id:
                                continue
                            if nm.text:
                                texts.append(f"[{btn_text[:30]}] {nm.text[:200]}")
                            _extract(nm)
                            last_msg_id = max(last_msg_id, nm.id)
                    except Exception:
                        pass

        return {"available": True, "urls": list(urls),
                "msg_count": len([m for m in messages if not m.out]),
                "sample_text": texts[0][:200] if texts else "",
                "clicked_buttons": clicked_buttons}
    except Exception as e:
        return {"available": False, "error": str(e)[:150]}

async def check_telegram_channel_info(bot_client, url: str) -> dict:
    """Bot API orqali Telegram kanal/bot ma'lumotlarini oladi."""
    parsed = urllib.parse.urlparse(url)
    if parsed.netloc not in TELEGRAM_DOMAINS:
        return {}
    path = parsed.path.strip("/")
    if not path:
        return {}
    if path.startswith("+"):
        return {"is_private_invite": True}
    username = path.split("?")[0].split("/")[0]
    if not username:
        return {}
    try:
        from telethon.tl.functions.contacts import ResolveUsernameRequest
        result = await bot_client(ResolveUsernameRequest(username))
        chat = result.chats[0] if result.chats else (result.users[0] if result.users else None)
        if not chat:
            return {"found": False, "username": username, "deleted": True}
        title = getattr(chat, 'title', '') or getattr(chat, 'first_name', '') or ''
        title_lower = title.lower().replace(" ", "").replace("_", "").replace("-", "")
        title_homograph = any(
            any(s in unicodedata.name(ch, "") for s in ("CYRILLIC", "GREEK"))
            for ch in title if ch.isalpha()
        )
        brand_in_title = []
        for brand in ALL_BRANDS:
            if brand.replace("_", "").replace("-", "") in title_lower:
                brand_in_title.append(brand)
        verified = getattr(chat, 'verified', False)
        members = getattr(chat, 'participants_count', None)
        un = getattr(chat, 'username', username)
        return {"found": True, "username": un, "title": title,
                "verified": verified, "member_count": members,
                "brand_in_title": brand_in_title, "title_has_homograph": title_homograph}
    except Exception:
        return {"found": False, "username": username, "deleted": True}

async def check_with_browser(url: str) -> dict:
    try:
        from playwright.async_api import async_playwright
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            ctx = await browser.new_context(user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            ))
            page = await ctx.new_page()
            try:
                await page.goto(url, wait_until="networkidle", timeout=15000)
            except Exception:
                pass
            final_url = page.url
            title = await page.title()
            has_password   = await page.locator("input[type='password']").count() > 0
            has_card_input = await page.locator(
                "input[name*='card'], input[placeholder*='card'], input[placeholder*='karta'], "
                "input[name*='pan'], input[maxlength='16'], input[maxlength='19']"
            ).count() > 0
            has_form = await page.locator("form").count() > 0
            await browser.close()
            return {"available": True, "final_url": final_url, "title": title[:120],
                    "redirected": final_url.rstrip("/") != url.rstrip("/"),
                    "has_password": has_password, "has_card_input": has_card_input,
                    "has_form": has_form}
    except ImportError:
        return {"available": False}
    except Exception:
        return {"available": False}


# ── Heuristik tekshiruvlar ──────────────────────────────────────────────────

def check_url_patterns(url: str, domain: str) -> list:
    warnings = []
    try:
        socket.inet_aton(domain)
        warnings.append("⚠️ Domain o'rniga IP manzil ishlatilgan")
    except socket.error:
        pass
    if "@" in url:
        warnings.append("⚠️ URL da `@` belgisi — asl manzil yashirilgan bo'lishi mumkin")
    found = [kw for kw in SUSPICIOUS_KEYWORDS if kw in url.lower()]
    if found:
        warnings.append(f"⚠️ Shubhali so'zlar URL da: `{', '.join(found[:4])}`")
    if len(domain.split(".")) > 4:
        warnings.append(f"⚠️ Ko'p subdomen: {len(domain.split('.')) - 2} ta")
    if len(url) > 150:
        warnings.append(f"⚠️ URL juda uzun: {len(url)} ta belgi")
    if domain.count("-") >= 2:
        warnings.append("⚠️ Domenda ko'p `-` — phishing belgisi")
    return warnings

def check_brand_impersonation(domain: str) -> list:
    warnings = []
    dl = domain.lower()
    for brand, official in ALL_BRANDS.items():
        if brand in dl and dl != official and not dl.endswith("." + official):
            tag = "🇺🇿" if brand in UZBEK_BRANDS else "🌐"
            warnings.append(f"⚠️ {tag} `{brand}` brendini taqlid qilishi mumkin! Rasmiy: `{official}`")
    return warnings

def check_homograph(domain: str) -> list:
    found = []
    for ch in domain:
        if ch in ".-0123456789":
            continue
        name = unicodedata.name(ch, "")
        if any(s in name for s in ("CYRILLIC", "GREEK", "ARABIC", "ARMENIAN")):
            found.append(ch)
    if found:
        return [f"⚠️ Homograf hujum! Unicode harflar: `{''.join(set(found))}`"]
    return []

def check_telegram_url(url: str) -> list:
    warnings = []
    parsed = urllib.parse.urlparse(url)
    if parsed.netloc not in TELEGRAM_DOMAINS:
        return warnings
    path = parsed.path.strip("/").lower().replace("_", "").replace("-", "")
    if not path or path.startswith("+"):
        if path.startswith("+"):
            warnings.append("⚠️ Yopiq Telegram kanal taklifi — ehtiyot bo'ling")
        return warnings
    for brand in ALL_BRANDS:
        if brand.replace("_", "").replace("-", "") in path:
            tag = "🇺🇿" if brand in UZBEK_BRANDS else "🌐"
            warnings.append(f"⚠️ {tag} Telegram username `{brand}` brendini taqlid qilishi mumkin")
    return warnings

def check_message_context_telethon(message) -> list:
    """Telethon xabar tuzilmasidan fishing belgilarini topadi."""
    warnings = []
    fwd = getattr(message, 'fwd_from', None)
    if fwd:
        from_name = getattr(fwd, 'from_name', '') or ''
        if from_name:
            nl = from_name.lower()
            if "postbot" in nl or "post bot" in nl:
                warnings.append("⚠️ @PostBot orqali forward — asl manba ataylab yashirilgan")
            for brand in ALL_BRANDS:
                if brand in nl:
                    warnings.append(f"⚠️ Forward yuboruvchi nomi `{brand}` brendini taqlid qilishi mumkin")
                    break
        if not getattr(fwd, 'channel_id', None) and not from_name:
            warnings.append("⚠️ Forward manba — nomi yo'q yashirin kanal")
    # Inline tugmalar
    markup = getattr(message, 'reply_markup', None)
    if markup and hasattr(markup, 'rows'):
        for row in markup.rows:
            for btn in row.buttons:
                btn_text = getattr(btn, 'text', '') or ''
                if btn_text:
                    found = [kw for kw in SCAM_BUTTON_WORDS if kw in btn_text.lower()]
                    if found:
                        warnings.append(f"⚠️ Tugma matni ijtimoiy muhandislik: '{btn_text}'")
                if hasattr(btn, 'url') and btn.url and 'web' in type(btn).__name__.lower():
                    warnings.append(f"⚠️ WebApp tugmasi — havola yashiringan: `{btn.url[:80]}`")
    return warnings


# ── Xavf hisoblash ──────────────────────────────────────────────────────────

def calculate_risk(domain, country, ssl_info, whois_info, redirected,
                   vt, urlhaus, abuse, pattern_w, brand_w, homograph_w,
                   tg_url_w=None, context_w=None) -> tuple:
    score = 0
    reasons = []

    if vt.get("available") and not vt.get("pending") and vt.get("malicious", 0) > 0:
        score += min(vt["malicious"] * 5, 40)
        reasons.append(f"🔴 VirusTotal: {vt['malicious']}/{vt['total']} engine xavfli dedi")
    if urlhaus.get("found"):
        score += 40
        reasons.append(f"🔴 URLhaus: bazada topildi — `{urlhaus.get('threat', 'malware')}`")
    if abuse.get("available") and abuse.get("abuse_score", 0) > 25:
        score += min(abuse["abuse_score"] // 4, 20)
        reasons.append(f"🔴 AbuseIPDB: {abuse['abuse_score']}/100 ({abuse.get('total_reports', 0)} shikoyat)")
    if homograph_w:
        score += 35
        reasons.extend(homograph_w)
    if brand_w:
        score += 25
        reasons.extend(brand_w)
    if tg_url_w:
        deleted = any("O'CHIRILGAN" in w for w in tg_url_w)
        score += 45 if deleted else 30
        reasons.extend(tg_url_w)
    if context_w:
        score += min(len(context_w) * 15, 35)
        reasons.extend(context_w)

    tld = "." + domain.split(".")[-1].lower()
    if tld in SUSPICIOUS_TLDS:
        score += 15
        reasons.append(f"⚠️ Shubhali kengaytma: `{tld}`")
    if country in SUSPICIOUS_COUNTRIES:
        score += 20
        reasons.append(f"⚠️ Server {country}da joylashgan")
    if not ssl_info["valid"]:
        score += 25
        reasons.append("⚠️ SSL sertifikat yo'q yoki yaroqsiz")
    elif ssl_info["days_left"] < 30:
        score += 10
        reasons.append(f"⚠️ SSL {ssl_info['days_left']} kun ichida tugaydi")

    age = whois_info.get("age_days")
    if age is not None:
        if age < 180:
            score += 30
            reasons.append(f"⚠️ Domen {age} kun oldin ro'yxatdan o'tgan — juda yangi")
        elif age < 365:
            score += 15
            reasons.append(f"⚠️ Domen nisbatan yangi ({age} kun)")

    if redirected:
        score += 10
        reasons.append("⚠️ Yashirin yo'naltirish aniqlandi")
    if pattern_w:
        score += min(len(pattern_w) * 8, 25)
        reasons.extend(pattern_w)

    return min(score, 100), reasons

def risk_label(score: int) -> str:
    if score <= 25:
        return "🟢 Xavfsiz"
    elif score <= 50:
        return "🟡 Shubhali"
    elif score <= 75:
        return "🟠 Xavfli"
    else:
        return "🔴 JUDA XAVFLI"

def format_age(days) -> str:
    if days is None:
        return "Noma'lum"
    if days >= 365:
        return f"{days // 365} yil {(days % 365) // 30} oy"
    return f"{days} kun"


# ── Asosiy tahlil ──────────────────────────────────────────────────────────

async def analyze_url(url: str, userbot=None, bot_client=None, context_w=None) -> tuple:
    """
    URL ni to'liq tahlil qiladi.
    Qaytaradi: (report_text, score, probe_urls)
    """
    loop = asyncio.get_event_loop()
    try:
        chain = await loop.run_in_executor(executor, get_redirect_chain, url)
        final_url = chain[-1] if chain else url
        redirected = len(chain) > 1

        parsed = urllib.parse.urlparse(final_url)
        domain = (parsed.netloc or parsed.path).split(":")[0]
        if "@" in domain:
            domain = domain.split("@")[-1]
        if not domain:
            return None, 0, []

        pattern_w   = check_url_patterns(final_url, domain)
        brand_w     = check_brand_impersonation(domain)
        homograph_w = check_homograph(domain)
        tg_url_w    = check_telegram_url(final_url)

        is_tg = domain in TELEGRAM_DOMAINS
        tg_channel = {}
        if is_tg and bot_client:
            tg_channel = await check_telegram_channel_info(bot_client, final_url)

        tg_channel_w = []
        if tg_channel.get("found"):
            if tg_channel.get("brand_in_title") and not tg_channel.get("verified"):
                for brand in tg_channel["brand_in_title"]:
                    tag = "🇺🇿" if brand in UZBEK_BRANDS else "🌐"
                    tg_channel_w.append(f"🔴 {tag} Kanal `{brand}` brendini taqlid qiladi lekin TASDIQLANMAGAN!")
            if tg_channel.get("title_has_homograph"):
                tg_channel_w.append(f"🔴 Kanal nomida unicode harflar: `{tg_channel.get('title', '')}`")
        elif tg_channel.get("deleted"):
            uname = tg_channel.get("username", "")
            tg_channel_w.append(f"🔴 @{uname} — O'CHIRILGAN! Spam yuborib ketishgan — klassik fishing belgisi")
        elif tg_channel.get("is_private_invite"):
            tg_channel_w.append("⚠️ Yopiq Telegram kanal taklifi — kim ekanligini ko'rib bo'lmaydi")

        probe = {"available": False}
        probe_urls = []
        if is_tg and userbot and not tg_channel.get("is_private_invite") and not tg_channel.get("deleted"):
            tg_path = urllib.parse.urlparse(final_url).path.strip("/").split("?")[0]
            if tg_path and not tg_path.startswith("+"):
                probe = await probe_telegram_bot(userbot, tg_path)
                probe_urls = probe.get("urls", [])

        try:
            ip = await loop.run_in_executor(executor, socket.gethostbyname, domain)
        except Exception:
            ip = "Noma'lum"

        results = await asyncio.gather(
            loop.run_in_executor(executor, _get_geo, ip),
            loop.run_in_executor(executor, check_ssl, domain),
            loop.run_in_executor(executor, check_whois, domain),
            loop.run_in_executor(executor, check_virustotal, final_url),
            loop.run_in_executor(executor, check_urlhaus, final_url),
            loop.run_in_executor(executor, check_abuseipdb, ip),
            check_with_browser(final_url),
            return_exceptions=True,
        )

        def _safe(r, default):
            return r if not isinstance(r, Exception) else default

        geo        = _safe(results[0], {})
        ssl_info   = _safe(results[1], {"valid": False, "days_left": 0, "issuer": "Noma'lum"})
        whois_info = _safe(results[2], {"age_days": None, "registrar": "Noma'lum"})
        vt         = _safe(results[3], {"available": False})
        urlhaus    = _safe(results[4], {"available": False})
        abuse      = _safe(results[5], {"available": False})
        browser    = _safe(results[6], {"available": False})

        country = geo.get("country", "Noma'lum")
        isp     = geo.get("isp", "Noma'lum")

        browser_w = []
        if browser.get("available"):
            if browser.get("has_card_input"):
                browser_w.append("🔴 Sahifada karta raqami kiritish shakli topildi!")
            if browser.get("has_password"):
                browser_w.append("🔴 Sahifada parol kiritish shakli topildi!")
            if browser.get("redirected"):
                browser_w.append(f"🔀 Brauzer haqiqiy manzilga o'tkazdi: `{browser.get('final_url', '')[:80]}`")

        all_tg_w = tg_url_w + tg_channel_w
        score, reasons = calculate_risk(
            domain, country, ssl_info, whois_info, redirected,
            vt, urlhaus, abuse, pattern_w, brand_w, homograph_w,
            tg_url_w=all_tg_w,
            context_w=(context_w or []) + browser_w,
        )
        label = risk_label(score)

        ssl_str = (f"✅ Ha ({ssl_info['days_left']} kun · {ssl_info['issuer']})"
                   if ssl_info["valid"] else "❌ Yo'q")

        if redirected and len(chain) > 1:
            chain_lines = "\n🔗 *Yo'naltirish zanjiri:*\n"
            for i, hop in enumerate(chain[:6]):
                prefix = "└→" if i == len(chain) - 1 else "├→"
                chain_lines += f"  {prefix} `{hop[:80]}`\n"
        else:
            chain_lines = "🔗 *Yo'naltirish:* Yo'q"

        if tg_channel.get("found"):
            verified_str = "✅ Tasdiqlangan" if tg_channel.get("verified") else "❌ Tasdiqlanmagan"
            members = tg_channel.get("member_count")
            members_str = f"{members:,}" if members else "Noma'lum"
            tg_block = (f"\n📱 *Telegram kanal:*\n"
                        f"📛 *Nomi:* {tg_channel.get('title', '—')}\n"
                        f"🔖 *Username:* @{tg_channel.get('username', '—')}\n"
                        f"✅ *Tasdiqlangan:* {verified_str}\n"
                        f"👥 *A'zolar:* {members_str}\n")
        elif tg_channel.get("deleted"):
            tg_block = (f"\n📱 *Telegram kanal:*\n"
                        f"🔖 *Username:* @{tg_channel.get('username', '')}\n"
                        f"🗑 *Holat:* O'CHIRILGAN — spam yuborib o'chirib ketishgan\n")
        elif tg_channel.get("is_private_invite"):
            tg_block = "\n📱 *Telegram:* Yopiq kanal taklifi\n"
        elif is_tg:
            tg_block = f"\n📱 *Telegram:* `{urllib.parse.urlparse(final_url).path.strip('/')}` — ma'lumot olishning imkoni yo'q\n"
        else:
            tg_block = ""

        probe_block = ""
        if probe.get("available"):
            msg_count = probe.get("msg_count", 0)
            sample = probe.get("sample_text", "")
            clicked = probe.get("clicked_buttons", [])
            clicked_str = ", ".join(f"'{b}'" for b in clicked[:4]) if clicked else "Yo'q"
            if probe_urls:
                urls_list = "\n".join(f"  🔗 `{u[:80]}`" for u in probe_urls[:5])
                probe_block = (f"\n🤖 *Userbot tekshiruvi ({msg_count} ta javob):*\n"
                               f"🖱 *Bosgan tugmalar:* {clicked_str}\n"
                               f"📨 *Bot matni:* {sample[:100]}\n"
                               f"🔗 *Topilgan havolalar:*\n{urls_list}\n")
            else:
                probe_block = (f"\n🤖 *Userbot tekshiruvi:* {msg_count} ta javob\n"
                               f"🖱 *Bosgan tugmalar:* {clicked_str}\n"
                               f"📨 *Bot matni:* {sample[:100] if sample else '—'}\n"
                               f"🔗 *Havolalar:* Topilmadi\n")

        if vt.get("available"):
            vt_str = ("⏳ Yangi havola — tahlil topshirildi" if vt.get("pending")
                      else f"{'🔴' if vt['malicious'] > 0 else '🟢'} {vt['malicious']}/{vt['total']} engine")
        else:
            vt_str = "⚪ API kalit yo'q (.env da VIRUSTOTAL_API_KEY)"

        uh_str = ("🔴 Bazada topildi!" if urlhaus.get("found")
                  else "🟢 URLhaus bazasida yo'q" if urlhaus.get("available")
                  else "⚪ Tekshirib bo'lmadi")

        if abuse.get("available"):
            s = abuse.get("abuse_score", 0)
            icon = "🔴" if s > 50 else "🟡" if s > 25 else "🟢"
            abuse_str = f"{icon} {s}/100 ({abuse.get('total_reports', 0)} shikoyat)"
        else:
            abuse_str = "⚪ API kalit yo'q (.env da ABUSEIPDB_API_KEY)"

        if browser.get("available"):
            b_title = browser.get("title", "—")
            b_card  = "🔴 BOR" if browser.get("has_card_input") else "🟢 Yo'q"
            b_pass  = "🔴 BOR" if browser.get("has_password") else "🟢 Yo'q"
            browser_block = (f"\n🌐 *Brauzer tekshiruvi:*\n"
                             f"📄 *Sahifa nomi:* {b_title}\n"
                             f"💳 *Karta shakli:* {b_card}\n"
                             f"🔑 *Parol shakli:* {b_pass}\n")
        else:
            browser_block = ""

        report = (
            f"🔍 *Havola tahlili:*\n"
            f"🌐 *Domen:* `{domain}`\n"
            f"📌 *IP:* `{ip}` · {country}\n"
            f"🏢 *Hosting:* {isp}\n"
            f"🛡 *SSL:* {ssl_str}\n"
            f"📅 *Domen yoshi:* {format_age(whois_info.get('age_days'))}\n"
            f"{chain_lines}"
            f"{tg_block}"
            f"{probe_block}"
            f"{browser_block}\n"
            f"*🔬 Threat Intelligence:*\n"
            f"🦠 *VirusTotal:* {vt_str}\n"
            f"☣️ *URLhaus:* {uh_str}\n"
            f"🚨 *AbuseIPDB:* {abuse_str}\n\n"
            f"📊 *Xavf darajasi: {score}/100 — {label}*"
        )

        if reasons:
            reasons_block = "\n\n*⚠️ Topilgan muammolar:*\n" + "\n".join(reasons[:8])
            if len(report) + len(reasons_block) < 4000:
                report += reasons_block

        return report, score, probe_urls

    except Exception:
        return f"🌐 *Havola:* `{url}`\n❌ Tahlil qilib bo'lmadi.", 0, []


def extract_urls_from_telethon_msg(message) -> set:
    """Telethon xabaridan barcha havolalarni topib oladi."""
    urls = set()
    text = message.text or message.message or ""
    entities = message.entities or []
    for ent in entities:
        etype = type(ent).__name__
        if etype == "MessageEntityUrl":
            url = text[ent.offset: ent.offset + ent.length]
            if not url.startswith(("http://", "https://")):
                url = "https://" + url
            urls.add(url)
        elif etype == "MessageEntityTextUrl":
            if ent.url:
                urls.add(ent.url)
    # Inline tugmalar
    markup = getattr(message, 'reply_markup', None)
    if markup and hasattr(markup, 'rows'):
        for row in markup.rows:
            for btn in row.buttons:
                if hasattr(btn, 'url') and btn.url:
                    urls.add(btn.url)
    # Oddiy matndan URL ni grep qilish
    import re
    for m in re.finditer(r'https?://[^\s\]>)"\']+', text):
        urls.add(m.group())
    return urls


# ══════════════════════════════════════════════════════════════════════
# 📱 APK TAHLIL
# ══════════════════════════════════════════════════════════════════════

import zipfile
import hashlib
import struct
import re as _re

# Xavfli Android ruxsatlari → (emoji+nom, xavf bali)
DANGEROUS_PERMISSIONS = {
    "READ_SMS":                  ("🔴 SMS o'qish",                        30),
    "SEND_SMS":                  ("🔴 SMS yuborish",                       30),
    "RECEIVE_SMS":               ("🔴 SMS qabul qilish",                   25),
    "RECEIVE_MMS":               ("🟠 MMS qabul qilish",                   20),
    "READ_CONTACTS":             ("🟠 Kontaktlarni o'qish",                20),
    "WRITE_CONTACTS":            ("🟠 Kontaktlarga yozish",                15),
    "READ_CALL_LOG":             ("🟠 Qo'ng'iroq tarixini o'qish",         20),
    "PROCESS_OUTGOING_CALLS":    ("🔴 Chiquvchi qo'ng'iroqlarni kuzatish", 25),
    "RECORD_AUDIO":              ("🔴 Mikrofon — ovoz yozish",             30),
    "CAMERA":                    ("🟠 Kamera",                             15),
    "ACCESS_FINE_LOCATION":      ("🟠 Aniq GPS joylashuv",                 20),
    "ACCESS_BACKGROUND_LOCATION":("🔴 Fonda GPS kuzatish",                 35),
    "READ_EXTERNAL_STORAGE":     ("🟡 Xotirani o'qish",                    10),
    "WRITE_EXTERNAL_STORAGE":    ("🟡 Xotiraga yozish",                    10),
    "MANAGE_EXTERNAL_STORAGE":   ("🔴 Barcha xotiraga kirish",             30),
    "RECEIVE_BOOT_COMPLETED":    ("🟠 Qurilma yonishi bilan autostart",     15),
    "FOREGROUND_SERVICE":        ("🟡 Fon xizmati",                        10),
    "REQUEST_INSTALL_PACKAGES":  ("🔴 Boshqa APK o'rnatish",               35),
    "BIND_ACCESSIBILITY_SERVICE":("🔴 Accessibility — klaviatura/ekran o'qish", 40),
    "SYSTEM_ALERT_WINDOW":       ("🔴 Ekran ustida oyna (overlay)",        30),
    "DISABLE_KEYGUARD":          ("🔴 Ekran qulfini o'chirish",            25),
    "READ_PHONE_STATE":          ("🟡 Telefon IMEI/SIM holati",            10),
    "GET_ACCOUNTS":              ("🟠 Google/boshqa hisoblarni o'qish",    15),
    "USE_CREDENTIALS":           ("🟠 Hisob ma'lumotlariga kirish",        20),
    "CHANGE_NETWORK_STATE":      ("🟡 Tarmoq sozlamalarini o'zgartirish",  10),
    "CHANGE_WIFI_STATE":         ("🟡 Wi-Fi sozlamalarini o'zgartirish",   10),
    "BLUETOOTH_ADMIN":           ("🟡 Bluetooth boshqaruvi",               10),
}

# Ma'lumot uzatish uchun ishlatiladigan shubhali URL patternlar
DATA_EXFIL_PATTERNS = [
    (_re.compile(r'https?://\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}'),
     "🔴 To'g'ridan IP manziliga ma'lumot uzatish"),
    (_re.compile(r'api\.telegram\.org/bot[\w:]+/send'),
     "🔴 Telegram bot API — ma'lumotlar Telegram botga yuborilmoqda!"),
    (_re.compile(r'https?://[^/\s]+\.(ru|cn|ir|by|kp)/'),
     "🟠 Shubhali mamlakatdagi server (RU/CN/IR/BY/KP)"),
    (_re.compile(r'https?://[^/\s]+\.onion'),
     "🔴 Tor tarmoqiga ma'lumot uzatish"),
    (_re.compile(r'(?:webhook|exfil|upload|collect|steal|gate|panel|log\.php)'),
     "🔴 C2/phishing panel endpoint aniqlandi"),
    (_re.compile(r'https?://ngrok\.io|\.ngrok\.app'),
     "🟠 ngrok tunnel — vaqtinchalik yashirin server"),
    (_re.compile(r'https?://[^/\s]+pastebin\.com'),
     "🟡 Pastebin — konfiguratsiya yashiringan bo'lishi mumkin"),
]


def _apk_hash(path: str) -> dict:
    """MD5, SHA1, SHA256 hisoblaydi."""
    md5 = hashlib.md5()
    sha1 = hashlib.sha1()
    sha256 = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            md5.update(chunk)
            sha1.update(chunk)
            sha256.update(chunk)
    return {"md5": md5.hexdigest(), "sha1": sha1.hexdigest(), "sha256": sha256.hexdigest()}


def _check_vt_hash(sha256: str) -> dict:
    """VirusTotal da hash orqali tekshirish (fayl yuklamaydi)."""
    vt_key = os.getenv("VIRUSTOTAL_API_KEY", "").strip()
    if not vt_key:
        return {"available": False}
    try:
        resp = requests.get(
            f"https://www.virustotal.com/api/v3/files/{sha256}",
            headers={"x-apikey": vt_key}, timeout=10
        )
        if resp.status_code == 200:
            stats = resp.json().get("data", {}).get("attributes", {}).get("last_analysis_stats", {})
            name  = resp.json().get("data", {}).get("attributes", {}).get("meaningful_name", "")
            return {"available": True,
                    "malicious": stats.get("malicious", 0),
                    "suspicious": stats.get("suspicious", 0),
                    "total": sum(stats.values()),
                    "name": name}
        if resp.status_code == 404:
            return {"available": True, "not_found": True}
    except Exception:
        pass
    return {"available": False}


def _extract_strings_from_binary(data: bytes, min_len: int = 5) -> list:
    """Binary ma'lumotdan o'qilishi mumkin bo'lgan satrlarni ajratib oladi."""
    # ASCII satrlar
    ascii_strings = _re.findall(rb'[\x20-\x7e]{%d,}' % min_len, data)
    results = set()
    for s in ascii_strings:
        try:
            results.add(s.decode('ascii'))
        except Exception:
            pass
    # UTF-16LE satrlar (Android binary XML da ishlatiladi)
    utf16_strings = _re.findall(rb'(?:[\x20-\x7e]\x00){%d,}' % min_len, data)
    for s in utf16_strings:
        try:
            decoded = s.decode('utf-16-le').strip('\x00').strip()
            if len(decoded) >= min_len:
                results.add(decoded)
        except Exception:
            pass
    return list(results)


def _find_permissions(strings: list) -> list:
    """Satrlar ichidan Android ruxsatlarini topadi."""
    found = []
    for s in strings:
        # android.permission.READ_SMS → READ_SMS
        if 'android.permission.' in s:
            perm = s.split('android.permission.')[-1].split('\x00')[0].strip()
            if perm and perm.upper() == perm and len(perm) > 2:
                found.append(perm)
        # com.google.android.c2dm.permission.RECEIVE kabi
        elif '.permission.' in s:
            perm = s.split('.permission.')[-1].split('\x00')[0].strip()
            if perm and len(perm) > 2:
                found.append(perm)
    return list(set(found))


def _find_network_endpoints(strings: list) -> list:
    """Satrlar ichidan URL va IP manzillarni topadi."""
    endpoints = set()
    url_pat = _re.compile(r'https?://[^\s\'"<>]{6,}')
    ip_pat  = _re.compile(r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b')
    for s in strings:
        for m in url_pat.finditer(s):
            u = m.group().rstrip('.,);\'\"')
            if len(u) > 10:
                endpoints.add(u)
        for m in ip_pat.finditer(s):
            ip = m.group()
            if not ip.startswith(('127.', '10.', '192.168.', '0.', '255.')):
                endpoints.add(ip)
    return list(endpoints)


# ── androguard chuqur tahlil ──────────────────────────────────────────

def _androguard_analyze(apk_path: str) -> dict:
    """androguard bilan to'liq DEX tahlili. Mavjud bo'lmasa xato qaytaradi."""
    result = {"available": False}
    try:
        from androguard.misc import AnalyzeAPK
        a, d, dx = AnalyzeAPK(apk_path)
        result["available"] = True
        result["package"]    = a.get_package() or ""
        result["permissions"] = list(a.get_permissions()) or []
        result["activities"]  = len(a.get_activities())
        result["services"]    = len(a.get_services())
        result["receivers"]   = len(a.get_receivers())

        # Barcha satrlarni DEX dan to'g'ri olish
        all_strings = set()
        for s_analysis in dx.get_strings():
            s = s_analysis.get_orig_value()
            if s and len(s) >= 4:
                all_strings.add(s)
        result["strings"] = list(all_strings)

        dangerous = []
        dex_loader = False
        reflection = False
        crypto_cls = []

        for cls in dx.get_classes():
            cn = cls.name
            if 'DexClassLoader' in cn or 'PathClassLoader' in cn:
                dex_loader = True
                dangerous.append("🔴 DexClassLoader — ishga tushib yangi DEX kodni yuklab oladi!")
            if 'reflect' in cn.lower():
                reflection = True
            if any(x in cn for x in ('Cipher', 'AES', 'DES', 'RSA', 'crypto')):
                crypto_cls.append(cn.replace('/', '.').strip('L;'))

        for ma in dx.get_methods():
            m  = ma.get_method()
            cn = m.get_class_name()
            mn = m.get_name()
            if cn == 'Ljava/lang/reflect/Method;' and mn == 'invoke':
                reflection = True
            if cn == 'Ljava/lang/Runtime;' and mn in ('exec', 'getRuntime'):
                dangerous.append("🔴 Runtime.exec() — qurilmada buyruq bajarilishi mumkin!")
            if cn == 'Ljava/lang/ProcessBuilder;':
                dangerous.append("🟠 ProcessBuilder — jarayon yaratish")

        result["dex_classloader"] = dex_loader
        result["reflection"]      = reflection
        result["crypto_classes"]  = list(set(crypto_cls))[:8]
        result["dangerous_apis"]  = list(set(dangerous))
    except ImportError:
        result["error"] = "androguard o'rnatilmagan"
    except Exception as e:
        result["error"] = str(e)[:200]
    return result


# ── Base64 va XOR shifr ochish ────────────────────────────────────────

def _find_base64_secrets(strings: list) -> list:
    """Base64 kodlangan shubhali satrlarni topib ochadi."""
    import base64 as _b64mod
    found = []
    b64_pat = _re.compile(r'^[A-Za-z0-9+/]{16,}={0,2}$')
    sus_kw = ('http', '://', 'api', 'token', 'key', 'pass', 'secret',
              'bot', 'telegram', 'cmd', 'exec', '.ru', '.cn', '.onion',
              'collect', 'steal', 'gate', 'panel')
    for s in strings:
        s = s.strip()
        if not b64_pat.match(s) or len(s) % 4 != 0:
            continue
        try:
            decoded = _b64mod.b64decode(s).decode('utf-8', errors='strict')
            if not decoded.isprintable() or len(decoded) < 6:
                continue
            if any(kw in decoded.lower() for kw in sus_kw):
                found.append(f"🟠 Base64 ochildi: `{s[:28]}` → `{decoded[:100]}`")
        except Exception:
            pass
        if len(found) >= 8:
            break
    return found


def _find_xor_secrets(strings: list) -> list:
    """Hex satrlarni XOR kalitlari bilan ochishga harakat qiladi."""
    found = []
    hex_pat = _re.compile(r'^[0-9a-fA-F]{16,}$')
    sus_kw = ('http', '://', 'api', '.com', '.ru', 'bot', 'token', 'cmd', 'exec')
    for s in strings:
        s = s.strip()
        if not hex_pat.match(s) or len(s) % 2 != 0:
            continue
        try:
            raw = bytes.fromhex(s)
        except Exception:
            continue
        for key in range(1, 256):
            xored = bytes(b ^ key for b in raw)
            try:
                text = xored.decode('utf-8')
                if text.isprintable() and any(kw in text.lower() for kw in sus_kw):
                    found.append(f"🔴 XOR(0x{key:02X}) ochildi: `{text[:100]}`")
                    break
            except Exception:
                pass
        if len(found) >= 5:
            break
    return found


# ── Hybrid Analysis sandbox ───────────────────────────────────────────

def _hybrid_submit(file_path: str, file_name: str) -> dict:
    """Hybrid Analysis (Falcon Sandbox) ga APK yuborib hisobot URL qaytaradi.
    Avval Android (200), bo'lmasa Windows 64bit (110), bo'lmasa quick-scan."""
    ha_key = os.getenv("HYBRID_ANALYSIS_API_KEY", "").strip()
    if not ha_key:
        return {"available": False}

    headers = {
        "api-key": ha_key,
        "User-Agent": "Falcon Sandbox",
        "Accept": "application/json"
    }

    # Sinab ko'riladigan muhitlar: Android → Windows 64bit → Windows 32bit
    for env_id in ["200", "110", "100"]:
        try:
            with open(file_path, 'rb') as f:
                resp = requests.post(
                    "https://www.hybrid-analysis.com/api/v2/submit/file",
                    headers=headers,
                    files={"file": (file_name, f, "application/octet-stream")},
                    data={"environment_id": env_id},
                    timeout=60
                )
            if resp.status_code == 404:
                continue
            data = resp.json()
            sha256 = data.get("sha256", "")
            job_id = data.get("job_id", "")
            if sha256 or job_id:
                env_label = {"200": "Android 8.1", "110": "Windows 64bit", "100": "Windows 32bit"}.get(env_id, env_id)
                return {
                    "available": True, "submitted": True,
                    "sha256": sha256, "job_id": job_id,
                    "env": env_label,
                    "report_url": f"https://www.hybrid-analysis.com/sample/{sha256}"
                }
            # "Not Found" yoki boshqa xato — keyingi muhitni sinash
            if "not found" in str(data).lower() or "message" in data:
                continue
            return {"available": True, "submitted": False, "error": str(data)[:150]}
        except Exception as e:
            continue

    # Quick-scan (muhitsiz — faqat statik tahlil)
    try:
        with open(file_path, 'rb') as f:
            resp = requests.post(
                "https://www.hybrid-analysis.com/api/v2/quick-scan/file",
                headers=headers,
                files={"file": (file_name, f, "application/octet-stream")},
                data={"scan_type": "all"},
                timeout=60
            )
        data = resp.json()
        sha256 = data.get("sha256", "")
        if sha256:
            return {
                "available": True, "submitted": True,
                "sha256": sha256, "env": "Quick Scan (statik)",
                "report_url": f"https://www.hybrid-analysis.com/sample/{sha256}"
            }
        return {"available": True, "submitted": False, "error": str(data)[:150]}
    except Exception as e:
        return {"available": False, "error": str(e)[:100]}


def _apk_risk_score(permissions: list, endpoints: list, vt: dict, file_size_mb: float) -> tuple:
    score = 0
    reasons = []

    # VirusTotal
    if vt.get("available") and not vt.get("not_found"):
        mal = vt.get("malicious", 0)
        if mal > 0:
            score += min(mal * 6, 50)
            reasons.append(f"🔴 VirusTotal: {mal}/{vt.get('total', 0)} engine xavfli dedi")
    elif vt.get("not_found"):
        score += 10
        reasons.append("🟡 VirusTotal bazasida topilmadi — yangi/noma'lum APK")

    # Ruxsatlar
    perm_score = 0
    found_dangerous = []
    for perm in permissions:
        info = DANGEROUS_PERMISSIONS.get(perm.upper())
        if info:
            label, pts = info
            if pts >= 25:
                perm_score += pts
                found_dangerous.append(f"{label} (`{perm}`)")
    score += min(perm_score, 60)
    reasons.extend(found_dangerous[:10])

    # Tarmoq endpointlari
    exfil_found = []
    for ep in endpoints:
        for pat, msg in DATA_EXFIL_PATTERNS:
            if pat.search(ep):
                short_ep = ep[:80]
                item = f"{msg}: `{short_ep}`"
                if item not in exfil_found:
                    exfil_found.append(item)
                    score += 20
                break
    reasons.extend(exfil_found[:8])

    # Fayl hajmi shubhali bo'lsa
    if file_size_mb > 50:
        score += 5
        reasons.append(f"🟡 Fayl hajmi katta: {file_size_mb:.1f} MB")

    return min(score, 100), reasons


async def analyze_apk(file_path: str, file_name: str = "app.apk") -> tuple:
    """
    APK faylni to'liq tahlil qiladi:
    1. androguard (agar mavjud) — chuqur DEX tahlili
    2. Regex fallback — binary string ajratish
    3. Base64 / XOR shifrlangan satrlarni ochish
    4. Hybrid Analysis sandbox (agar API kalit bo'lsa)
    5. VirusTotal hash tekshiruvi
    Qaytaradi: (report_text, risk_score)
    """
    loop = asyncio.get_event_loop()
    try:
        file_size    = os.path.getsize(file_path)
        file_size_mb = file_size / (1024 * 1024)

        # ZIP tekshiruvi
        try:
            zf    = zipfile.ZipFile(file_path, 'r')
            names = zf.namelist()
        except zipfile.BadZipFile:
            return "❌ Bu haqiqiy APK fayl emas (ZIP ochib bo'lmadi).", 80

        has_manifest = 'AndroidManifest.xml' in names
        has_dex      = any(n.endswith('.dex') for n in names)
        if not has_manifest or not has_dex:
            zf.close()
            return "❌ AndroidManifest.xml yoki classes.dex topilmadi — haqiqiy APK emas.", 70

        dex_names = [n for n in names if n.endswith('.dex')]
        zf.close()

        # ── Hash + VirusTotal + Hybrid Analysis parallel ──────────────
        hashes = await loop.run_in_executor(executor, _apk_hash, file_path)
        vt, hybrid = await asyncio.gather(
            loop.run_in_executor(executor, _check_vt_hash, hashes['sha256']),
            loop.run_in_executor(executor, _hybrid_submit, file_path, file_name),
        )

        # ── 1. androguard (afzal) ─────────────────────────────────────
        ag = await loop.run_in_executor(executor, _androguard_analyze, file_path)

        if ag.get("available"):
            permissions  = [p.split('.')[-1] for p in ag.get("permissions", [])]
            all_strings  = ag.get("strings", [])
            pkg_name     = ag.get("package", "")
            dex_classloader = ag.get("dex_classloader", False)
            reflection      = ag.get("reflection", False)
            crypto_cls      = ag.get("crypto_classes", [])
            ag_dangerous    = ag.get("dangerous_apis", [])
            analysis_mode   = "androguard"
        else:
            # ── 2. Regex fallback ─────────────────────────────────────
            analysis_mode   = "regex"
            dex_classloader = False
            reflection      = False
            crypto_cls      = []
            ag_dangerous    = []
            zf2 = zipfile.ZipFile(file_path, 'r')
            manifest_data = zf2.read('AndroidManifest.xml')
            manifest_strings = await loop.run_in_executor(
                executor, _extract_strings_from_binary, manifest_data, 4)
            all_strings = list(manifest_strings)
            for dn in dex_names[:3]:
                dex_data = zf2.read(dn)
                dex_str  = await loop.run_in_executor(
                    executor, _extract_strings_from_binary, dex_data, 6)
                all_strings.extend(dex_str)
            zf2.close()
            permissions = _find_permissions(all_strings + manifest_strings)
            pkg_name = ""
            for s in manifest_strings:
                if s.count('.') >= 2 and s.replace('.','').replace('_','').isalnum() and len(s) > 8:
                    pkg_name = s
                    break

        # ── 3. Base64 va XOR shifrlangan satrlarni ochish ─────────────
        b64_found = await loop.run_in_executor(executor, _find_base64_secrets, all_strings)
        xor_found = await loop.run_in_executor(executor, _find_xor_secrets,    all_strings)

        # ── 4. Tarmoq endpointlari ────────────────────────────────────
        endpoints = _find_network_endpoints(all_strings)

        # ── 5. Xavf hisoblash ─────────────────────────────────────────
        score, reasons = _apk_risk_score(permissions, endpoints, vt, file_size_mb)

        # androguard topgan xavfli API lar
        if dex_classloader:
            score = min(score + 35, 100)
        if ag_dangerous:
            score = min(score + len(ag_dangerous) * 10, 100)
            reasons.extend(ag_dangerous[:4])
        if reflection:
            score = min(score + 10, 100)
            reasons.append("🟠 Reflection ishlatilgan — kodni yashirish usuli")
        if b64_found:
            score = min(score + len(b64_found) * 8, 100)
            reasons.extend(b64_found[:4])
        if xor_found:
            score = min(score + len(xor_found) * 15, 100)
            reasons.extend(xor_found[:3])

        label = risk_label(score)

        # ── Formatlash ────────────────────────────────────────────────
        dangerous_perms, normal_perms = [], []
        for p in sorted(set(permissions)):
            info = DANGEROUS_PERMISSIONS.get(p.upper())
            if info and info[1] >= 15:
                dangerous_perms.append(f"  {info[0]}")
            elif info and info[1] > 0:
                normal_perms.append(f"  🟡 {p}")

        perms_str = ""
        if dangerous_perms:
            perms_str += "\n🚨 *Xavfli ruxsatlar:*\n" + "\n".join(dangerous_perms[:15])
        if normal_perms:
            perms_str += "\n🟡 *Oddiy ruxsatlar:*\n" + "\n".join(normal_perms[:6])
        if not permissions:
            perms_str = "\n⚪ Ruxsatlar topilmadi (yashirilgan bo'lishi mumkin)"

        ep_lines = ""
        if endpoints:
            ep_show = []
            for ep in endpoints[:8]:
                is_sus = any(pat.search(ep) for pat, _ in DATA_EXFIL_PATTERNS)
                ep_show.append(f"  {'🔴' if is_sus else '⚪'} `{ep[:70]}`")
            ep_lines = "\n🌐 *Tarmoq endpointlari:*\n" + "\n".join(ep_show)

        # Shifrlangan satrlar bloki
        crypto_block = ""
        if b64_found or xor_found:
            crypto_block = "\n🔓 *Shifrlangan satrlar (ochildi):*\n"
            for item in (b64_found + xor_found)[:6]:
                crypto_block += f"  {item}\n"
        if crypto_cls:
            crypto_block += "\n🔐 *Crypto sinflar ishlatilgan:*\n"
            for c in crypto_cls[:4]:
                crypto_block += f"  `{c}`\n"

        # androguard qo'shimcha ma'lumot
        ag_block = ""
        if ag.get("available"):
            flags = []
            if dex_classloader:
                flags.append("🔴 DexClassLoader")
            if reflection:
                flags.append("🟠 Reflection")
            if ag.get("services", 0) > 3:
                flags.append(f"🟡 {ag['services']} ta servis")
            if flags:
                ag_block = "\n🔬 *Chuqur tahlil:* " + " · ".join(flags) + "\n"
        elif ag.get("error") and "o'rnatilmagan" not in ag.get("error", ""):
            ag_block = f"\n⚪ androguard xatosi: {ag.get('error', '')[:60]}\n"

        # VirusTotal
        if vt.get("available") and not vt.get("not_found"):
            mal    = vt.get("malicious", 0)
            vt_str = f"{'🔴' if mal > 0 else '🟢'} {mal}/{vt.get('total', 0)} engine"
        elif vt.get("not_found"):
            vt_str = "🟡 Bazada topilmadi"
        else:
            vt_str = "⚪ API kalit yo'q"

        # Hybrid Analysis
        if hybrid.get("submitted"):
            env_info = f" `({hybrid.get('env', '')})`" if hybrid.get('env') else ""
            ha_str = f"✅ Yuborildi{env_info} → [Hisobot]({hybrid.get('report_url', '')})\n_(10–15 daqiqa ichida tayyor)_"
        elif hybrid.get("available") is False and not os.getenv("HYBRID_ANALYSIS_API_KEY", "").strip():
            ha_str = "⚪ API kalit yo'q"
        else:
            ha_str = f"⚠️ Yuborib bo'lmadi: {hybrid.get('error', '')[:60]}"

        _pkg   = pkg_name if pkg_name else "Noma'lum"
        _mode  = "androguard" if analysis_mode == "androguard" else "Regex (androguard yo'q)"
        report = (
            f"📱 *APK Tahlil Hisoboti*\n\n"
            f"📦 *Paket:* `{_pkg}`\n"
            f"📏 *Hajm:* {file_size_mb:.2f} MB · DEX: {len(dex_names)} ta\n"
            f"🔬 *Tahlil usuli:* {_mode}\n"
            f"🔑 *MD5:* `{hashes['md5']}`\n"
            f"🔑 *SHA256:* `{hashes['sha256'][:32]}...`\n\n"
            f"🦠 *VirusTotal:* {vt_str}\n"
            f"🧪 *Hybrid Analysis:* {ha_str}\n"
            f"{ag_block}"
            f"{perms_str}"
            f"{ep_lines}"
            f"{crypto_block}\n"
            f"📊 *Xavf darajasi: {score}/100 — {label}*"
        )

        if reasons:
            rb = "\n\n*⚠️ Topilgan muammolar:*\n" + "\n".join(reasons[:12])
            if len(report) + len(rb) < 4000:
                report += rb

        return report, score

    except Exception as e:
        return f"❌ APK tahlil xatosi: {e}", 0


# ══════════════════════════════════════════════════════════════════════
# 🎵 OGG / AUDIO FAYL TAHLIL
# ══════════════════════════════════════════════════════════════════════

OGG_MAGIC    = b'OggS'
VORBIS_MAGIC = b'\x01vorbis'


def _parse_ogg_comments(data: bytes) -> dict:
    """
    Vorbis comment header dan metadata o'qiydi.
    Format: \x03vorbis → vendor string → user comments
    """
    result = {"vendor": "", "comments": [], "suspicious": []}
    try:
        pos = data.find(b'\x03vorbis')
        if pos < 0:
            return result
        pos += 7  # skip \x03vorbis

        vendor_len = struct.unpack_from('<I', data, pos)[0]
        pos += 4
        vendor = data[pos:pos + vendor_len].decode('utf-8', errors='replace')
        result["vendor"] = vendor
        pos += vendor_len

        comment_count = struct.unpack_from('<I', data, pos)[0]
        pos += 4

        for _ in range(min(comment_count, 50)):
            if pos + 4 > len(data):
                break
            clen = struct.unpack_from('<I', data, pos)[0]
            pos += 4
            if clen > 10000 or pos + clen > len(data):
                break
            comment = data[pos:pos + clen].decode('utf-8', errors='replace')
            result["comments"].append(comment)
            pos += clen

            # Shubhali kontent tekshirish
            cl = comment.lower()
            if any(kw in cl for kw in ['http', 'password', 'token', 'key=', 'secret', 'cmd=', 'exec']):
                result["suspicious"].append(comment[:200])
    except Exception:
        pass
    return result


def _ogg_file_info(data: bytes) -> dict:
    """OGG fayl haqida asosiy ma'lumotlar."""
    info = {"pages": 0, "is_valid": False, "has_audio": False}
    pos = 0
    page_count = 0
    while pos + 27 <= len(data):
        if data[pos:pos + 4] != OGG_MAGIC:
            break
        # OGG page header
        if pos + 27 > len(data):
            break
        segments = data[pos + 26]
        seg_table_end = pos + 27 + segments
        if seg_table_end > len(data):
            break
        seg_sizes = list(data[pos + 27: seg_table_end])
        page_size = sum(seg_sizes)
        page_count += 1
        # Vorbis header tekshiruvi
        payload_start = seg_table_end
        if payload_start < len(data) and data[payload_start:payload_start + 7] == VORBIS_MAGIC:
            info["has_audio"] = True
        pos = seg_table_end + page_size
        if page_count > 100:
            break
    info["pages"] = page_count
    info["is_valid"] = page_count > 0
    return info


async def analyze_ogg(file_path: str) -> tuple:
    """
    OGG/audio faylni tahlil qiladi.
    Qaytaradi: (report_text, risk_score)
    """
    loop = asyncio.get_event_loop()
    try:
        file_size = os.path.getsize(file_path)
        file_size_kb = file_size / 1024

        with open(file_path, 'rb') as f:
            data = f.read()

        score = 0
        findings = []

        # 1. Magic bytes tekshiruvi
        is_ogg = data[:4] == OGG_MAGIC
        if not is_ogg:
            score += 60
            magic_hex = data[:4].hex().upper()
            findings.append(f"🔴 Fayl OGG EMAS! Magic bytes: `{magic_hex}` — yashirin fayl bo'lishi mumkin!")
            # Haqiqiy fayl turini aniqlash
            known_magic = {
                b'PK\x03\x04': "ZIP/APK/JAR",
                b'MZ': "Windows EXE",
                b'\x7fELF': "Linux ELF (Linux bajariladigan fayl)",
                b'\xca\xfe\xba\xbe': "Java CLASS fayl",
                b'%PDF': "PDF",
                b'\xff\xd8\xff': "JPEG rasm",
                b'\x89PNG': "PNG rasm",
            }
            for magic, name in known_magic.items():
                if data[:len(magic)] == magic:
                    findings.append(f"🔴 Haqiqiy format: **{name}** — OGG deb niqoblangan!")
                    score += 30
                    break

        # 2. OGG sahifalarini parse qilish
        ogg_info = {}
        comments_data = {}
        if is_ogg:
            ogg_info  = await loop.run_in_executor(executor, _ogg_file_info, data)
            comments_data = await loop.run_in_executor(executor, _parse_ogg_comments, data)

            if not ogg_info.get("is_valid"):
                score += 20
                findings.append("🟠 OGG format noto'g'ri tuzilgan — shubhali")

            if not ogg_info.get("has_audio"):
                score += 25
                findings.append("🔴 OGG da audio ma'lumot topilmadi — niqoblangan fayl bo'lishi mumkin!")

            # 3. Vorbis metadata tekshiruvi
            if comments_data.get("suspicious"):
                score += 40
                for s in comments_data["suspicious"][:3]:
                    findings.append(f"🔴 Metadatada shubhali ma'lumot: `{s[:100]}`")

            # URL yoki kod metadata da bormi
            for comment in comments_data.get("comments", []):
                if _re.search(r'https?://', comment):
                    score += 20
                    findings.append(f"🟠 Metadatada havola: `{comment[:100]}`")
                    break

        # 4. Hajm anomaliyasi (64kbps OGG → ~8KB/s)
        # Agar sahifalar ko'p bo'lsa, lekin hajm g'alati bo'lsa
        if is_ogg and ogg_info.get("pages", 0) > 0:
            pages = ogg_info["pages"]
            expected_max_kb = pages * 10  # taxminan
            if file_size_kb > expected_max_kb * 50:
                score += 15
                findings.append(f"🟡 Fayl hajmi g'alati katta: {file_size_kb:.0f} KB / {pages} sahifa")

        # 5. Hash va VirusTotal
        sha256 = hashlib.sha256(data).hexdigest()
        md5    = hashlib.md5(data).hexdigest()
        vt = await loop.run_in_executor(executor, _check_vt_hash, sha256)

        if vt.get("available") and not vt.get("not_found"):
            mal = vt.get("malicious", 0)
            if mal > 0:
                score += min(mal * 6, 40)
                findings.append(f"🔴 VirusTotal: {mal}/{vt.get('total', 0)} engine xavfli dedi")
            vt_str = f"{'🔴' if mal > 0 else '🟢'} {mal}/{vt.get('total', 0)} engine"
        elif vt.get("not_found"):
            vt_str = "🟡 Bazada topilmadi"
        else:
            vt_str = "⚪ API kalit yo'q"

        score = min(score, 100)
        label = risk_label(score)

        # Metadata bloki
        meta_block = ""
        if comments_data:
            vendor = comments_data.get("vendor", "")
            comments = comments_data.get("comments", [])
            if vendor:
                meta_block += f"🎙 *Encoder:* `{vendor[:80]}`\n"
            if comments:
                clean = [c for c in comments if not any(kw in c.lower()
                         for kw in ['http', 'password', 'token', 'secret'])]
                if clean:
                    meta_block += "🏷 *Metadata:*\n" + "\n".join(f"  `{c[:80]}`" for c in clean[:5]) + "\n"

        report = (
            f"🎵 *OGG/Audio Fayl Tahlil Hisoboti*\n\n"
            f"📏 *Hajm:* {file_size_kb:.1f} KB\n"
            f"{'✅ Haqiqiy OGG' if is_ogg else '❌ OGG EMAS'}"
            + (f" · {ogg_info.get('pages', 0)} sahifa" if is_ogg and ogg_info else "")
            + f"\n"
            f"🔑 *MD5:* `{md5}`\n"
            f"🔑 *SHA256:* `{sha256[:32]}...`\n"
            f"🦠 *VirusTotal:* {vt_str}\n"
            f"{meta_block}\n"
            f"📊 *Xavf darajasi: {score}/100 — {label}*"
        )

        if findings:
            findings_block = "\n\n*⚠️ Topilgan muammolar:*\n" + "\n".join(findings[:10])
            if len(report) + len(findings_block) < 4000:
                report += findings_block

        return report, score

    except Exception as e:
        return f"❌ OGG tahlil xatosi: {e}", 0
