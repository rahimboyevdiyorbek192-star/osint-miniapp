@echo off
title KIBER STANSIYA - O'rnatish
color 0A
echo ============================================
echo   KIBER STANSIYA OSINT PRO - O'RNATISH
echo ============================================
echo.

:: Python borligini tekshirish
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Python topilmadi. Yuklanmoqda...
    echo.
    :: Python 3.12 yuklab olish
    curl -o python_installer.exe https://www.python.org/ftp/python/3.12.0/python-3.12.0-amd64.exe
    echo [*] Python o'rnatilmoqda...
    python_installer.exe /quiet InstallAllUsers=1 PrependPath=1 Include_test=0
    del python_installer.exe
    echo [+] Python o'rnatildi!
) else (
    echo [+] Python topildi!
)

echo.
echo [*] Kerakli kutubxonalar o'rnatilmoqda...
echo.

pip install telethon aiosqlite openpyxl python-dotenv numpy reportlab --quiet
if %errorlevel% neq 0 (
    pip3 install telethon aiosqlite openpyxl python-dotenv numpy reportlab --quiet
)

echo [+] numpy o'rnatildi — musiqa taqqoslash 100x tezroq!

echo.
echo ============================================
echo   [+] O'RNATISH MUVAFFAQIYATLI YAKUNLANDI!
echo ============================================
echo.
echo Endi START_BOT.bat ni ishga tushiring.
echo.
pause
